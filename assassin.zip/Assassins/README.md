# README #

-custom circles
-custom rounded rectangles
-nav drawer
-make all activities (outline)
-establish all transitions
-put roboto font in assets
-make color.xml file (Rebecca will do this because i have the colors)